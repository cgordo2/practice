Name: Clayton Gordon
Clemson Email Address:cgordo2@clemson.edu
CpSc8270 : Languge Translation

Project no: 4
Project due date: October 27, 2014
Project description: Grammar Comprehension:Spaceless Python

The Specs that I implemented are: I was able resolve all the reduce reduce and shift reduce conflicts in the grammar. 
                                  In order to get 100 percent, i had to place //LCOV_EXCL_LINE on the same line with "\n" to exclude it. 

The Specs that I was unable to implement are:
Extras: None
