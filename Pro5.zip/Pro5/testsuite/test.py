def f():

 x = 2
 y = 3
   print y + x
 end   